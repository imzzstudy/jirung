var express = require('express');
var router = express.Router();

var Account = require('../models/Account');//계정 DB 

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/join', function(req, res, next) {
  res.render('join');
});

router.post('/join', function(req, res, next) {
  var name = req.body.name;
  var id = req.body.id;
  var password = req.body.pw;
  var bank = req.body.bankName;
  var acNum = req.body.acNum;
  console.log("----------");
  Account.create({
    name: name,
    id:id,
    password: password,
    bank: bank,
    accountNum: acNum
  });
  console.log("-----회원가입 성공!-----");
  res.redirect('/users/login');
});

router.get('/login', function(req, res, next) {
  res.render('login');
});

router.post('/login', function (req, res, next) {
  Account.findOne({
      id: req.body.id
  }, function (err, exists) {
      if (err) console.log(err);
      if (exists) {
          var check = exists.password;
          if (check == req.body.password) {
              req.session.user = {
                  objId: exists._id,
                  id: exists.id,
                  password: exists.password,
                  name: exists.name,
                  autorized: true
              };
              console.log('ok');
              res.redirect('/');
          } else {
              res.send('존재하지 않습니다.pw');
          }
      }else{
        res.send('존재하지 않습니다.id');
      }
  });
});

module.exports = router;
